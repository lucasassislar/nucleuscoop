READ ME FIRST! 

This modification allows users to enable the split-screen game mode for story mode only.
Inorder to run this patch, 2 pads are required inorder to play.
The mouse/keyboard function has been disabled to minimize the amount of bugs it causes.
This patch is NOT for pirates so BUY a LEGAL copy.

THIS IS NOT OFFICIAL! USE AT YOUR OWN RISK.


--- Installation -------------------------------------------------------------------------------------------------------------------------------

Inorder to install this patch, just follow the simple steps below.

1. Extract the .ZIP/.RAR using Winrar.
2. Go to your RE5 installation directory usually: C:\program files\CAPCOM\Resident Evil 5\
3. Drag 'n' drop all the archive contents into your RE5 installation directory. If administrative privilages are required; please allow them.


--- DX9/10 Configuration -----------------------------------------------------------------------------------------------------------------------

Users now have the ability to use a checkbox which determins where they want the game to be run in Dx9/10 mode.
The box appears upon start up.


--- Known bugs ---------------------------------------------------------------------------------------------------------------------------------
 
- Some users will experience degraded graphical quality on the second player's screen. I believe the game does this automatically to maximize performance.
- Pause menu, due to additional options in the system setting menu; the description text overlays the buttons.

Other than that, this modification is perfectly playable.


--- Credits  -----------------------------------------------------------------------------------------------------------------------------------

- maluc
- Mr.NightmareTM
- Breeanna


--- History ------------------------------------------------------------------------------------------------------------------------------------
